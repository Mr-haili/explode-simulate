import {
  Particle,
  ParticleLayouter,
  ParticleRender,
  ParticleSystem,
  PVector2
} from './components';
import {
  Scene,
  Sprite
} from 'spritejs';

console.log('开始摇滚吧');

const layouter = new ParticleLayouter();
const render = new ParticleRender('#demo-quickStart');
const particleSystem = new ParticleSystem(
  layouter,
  render
);

for(let i = 10; i >= 0; i-= 1) {
  const position = new PVector2(0, 0);
  const size = new PVector2(100, 100);
  const acceleration = new PVector2(5 * Math.random(), 5 * Math.random());
  const velocity = new PVector2(10 * Math.random(), 10 * Math.random());

  particleSystem.emit(
    position,
    size,
    acceleration,
    velocity
  );
}

let total = 0;
let gap = 10;
let intervalId = setInterval(() => {
  console.log('----------');
  particleSystem.run();
  total += gap;
  if(total > 3000) clearInterval(intervalId);
}, gap);
