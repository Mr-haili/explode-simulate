import {
  Particle
} from './particle'

export interface ParticleRecord {
  particle: Particle,
  sprite: any
}
