
export function isNumber(x: any): x is number {
  return 'number' === typeof x;
}
